﻿namespace Game_over
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            label1 = new Label();
            maskedTextBox1 = new MaskedTextBox();
            maskedTextBox2 = new MaskedTextBox();
            maskedTextBox3 = new MaskedTextBox();
            maskedTextBox4 = new MaskedTextBox();
            label2 = new Label();
            button2 = new Button();
            groupBox1 = new GroupBox();
            maskedTextBox18 = new MaskedTextBox();
            maskedTextBox15 = new MaskedTextBox();
            label19 = new Label();
            label18 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            maskedTextBox8 = new MaskedTextBox();
            maskedTextBox7 = new MaskedTextBox();
            groupBox2 = new GroupBox();
            label20 = new Label();
            maskedTextBox16 = new MaskedTextBox();
            maskedTextBox17 = new MaskedTextBox();
            label22 = new Label();
            label11 = new Label();
            label12 = new Label();
            label9 = new Label();
            label10 = new Label();
            maskedTextBox10 = new MaskedTextBox();
            maskedTextBox9 = new MaskedTextBox();
            maskedTextBox5 = new MaskedTextBox();
            label3 = new Label();
            button3 = new Button();
            maskedTextBox6 = new MaskedTextBox();
            label4 = new Label();
            groupBox3 = new GroupBox();
            label24 = new Label();
            maskedTextBox21 = new MaskedTextBox();
            label23 = new Label();
            label21 = new Label();
            maskedTextBox20 = new MaskedTextBox();
            maskedTextBox19 = new MaskedTextBox();
            label17 = new Label();
            label16 = new Label();
            label15 = new Label();
            maskedTextBox14 = new MaskedTextBox();
            maskedTextBox11 = new MaskedTextBox();
            label14 = new Label();
            label13 = new Label();
            maskedTextBox13 = new MaskedTextBox();
            maskedTextBox12 = new MaskedTextBox();
            button4 = new Button();
            maskedTextBox22 = new MaskedTextBox();
            maskedTextBox23 = new MaskedTextBox();
            label25 = new Label();
            label27 = new Label();
            label26 = new Label();
            button5 = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(43, 78);
            button1.Name = "button1";
            button1.Size = new Size(183, 81);
            button1.TabIndex = 0;
            button1.Text = "อ.สมชาย ใจดี";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(350, 71);
            label1.Name = "label1";
            label1.Size = new Size(223, 20);
            label1.TabIndex = 1;
            label1.Text = "นักศึกษาในที่ปรึกษาของ สมชาย ใจดี:";
            // 
            // maskedTextBox1
            // 
            maskedTextBox1.Location = new Point(322, 110);
            maskedTextBox1.Name = "maskedTextBox1";
            maskedTextBox1.Size = new Size(150, 27);
            maskedTextBox1.TabIndex = 2;
            // 
            // maskedTextBox2
            // 
            maskedTextBox2.Location = new Point(291, 26);
            maskedTextBox2.Name = "maskedTextBox2";
            maskedTextBox2.Size = new Size(150, 27);
            maskedTextBox2.TabIndex = 3;
            // 
            // maskedTextBox3
            // 
            maskedTextBox3.Location = new Point(291, 105);
            maskedTextBox3.Name = "maskedTextBox3";
            maskedTextBox3.Size = new Size(150, 27);
            maskedTextBox3.TabIndex = 4;
            // 
            // maskedTextBox4
            // 
            maskedTextBox4.Location = new Point(322, 28);
            maskedTextBox4.Name = "maskedTextBox4";
            maskedTextBox4.Size = new Size(150, 27);
            maskedTextBox4.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(37, 26);
            label2.Name = "label2";
            label2.Size = new Size(223, 20);
            label2.TabIndex = 6;
            label2.Text = "นักศึกษาในที่ปรึกษาของ วิไล รักเรียน:";
            // 
            // button2
            // 
            button2.Location = new Point(43, 230);
            button2.Name = "button2";
            button2.Size = new Size(183, 81);
            button2.TabIndex = 7;
            button2.Text = "อ.วิไล รักเรียน";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label25);
            groupBox1.Controls.Add(maskedTextBox22);
            groupBox1.Controls.Add(maskedTextBox18);
            groupBox1.Controls.Add(maskedTextBox15);
            groupBox1.Controls.Add(label19);
            groupBox1.Controls.Add(label18);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(maskedTextBox8);
            groupBox1.Controls.Add(maskedTextBox7);
            groupBox1.Controls.Add(maskedTextBox1);
            groupBox1.Controls.Add(maskedTextBox4);
            groupBox1.Location = new Point(303, 43);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(976, 157);
            groupBox1.TabIndex = 8;
            groupBox1.TabStop = false;
            groupBox1.Text = "ช่อง1";
            // 
            // maskedTextBox18
            // 
            maskedTextBox18.Location = new Point(833, 110);
            maskedTextBox18.Name = "maskedTextBox18";
            maskedTextBox18.Size = new Size(125, 27);
            maskedTextBox18.TabIndex = 14;
            // 
            // maskedTextBox15
            // 
            maskedTextBox15.Location = new Point(833, 32);
            maskedTextBox15.Name = "maskedTextBox15";
            maskedTextBox15.Size = new Size(125, 27);
            maskedTextBox15.TabIndex = 11;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(769, 113);
            label19.Name = "label19";
            label19.Size = new Size(40, 20);
            label19.TabIndex = 10;
            label19.Text = "สาขา";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(769, 35);
            label18.Name = "label18";
            label18.Size = new Size(40, 20);
            label18.TabIndex = 9;
            label18.Text = "สาขา";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(290, 113);
            label8.Name = "label8";
            label8.Size = new Size(26, 20);
            label8.TabIndex = 8;
            label8.Text = "ชื่อ";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(290, 31);
            label7.Name = "label7";
            label7.Size = new Size(26, 20);
            label7.TabIndex = 7;
            label7.Text = "ชื่อ";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(512, 110);
            label6.Name = "label6";
            label6.Size = new Size(84, 20);
            label6.TabIndex = 6;
            label6.Text = "รหัสนักศึกษา";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(512, 31);
            label5.Name = "label5";
            label5.Size = new Size(84, 20);
            label5.TabIndex = 5;
            label5.Text = "รหัสนักศึกษา";
            // 
            // maskedTextBox8
            // 
            maskedTextBox8.Location = new Point(602, 103);
            maskedTextBox8.Name = "maskedTextBox8";
            maskedTextBox8.Size = new Size(125, 27);
            maskedTextBox8.TabIndex = 4;
            // 
            // maskedTextBox7
            // 
            maskedTextBox7.Location = new Point(602, 28);
            maskedTextBox7.Name = "maskedTextBox7";
            maskedTextBox7.Size = new Size(125, 27);
            maskedTextBox7.TabIndex = 3;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label27);
            groupBox2.Controls.Add(maskedTextBox23);
            groupBox2.Controls.Add(label20);
            groupBox2.Controls.Add(maskedTextBox16);
            groupBox2.Controls.Add(maskedTextBox17);
            groupBox2.Controls.Add(label22);
            groupBox2.Controls.Add(label11);
            groupBox2.Controls.Add(label12);
            groupBox2.Controls.Add(label9);
            groupBox2.Controls.Add(label10);
            groupBox2.Controls.Add(maskedTextBox10);
            groupBox2.Controls.Add(maskedTextBox9);
            groupBox2.Controls.Add(maskedTextBox3);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(maskedTextBox2);
            groupBox2.Location = new Point(313, 240);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(966, 138);
            groupBox2.TabIndex = 9;
            groupBox2.TabStop = false;
            groupBox2.Text = "ช่อง2";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(771, 33);
            label20.Name = "label20";
            label20.Size = new Size(40, 20);
            label20.TabIndex = 11;
            label20.Text = "สาขา";
            // 
            // maskedTextBox16
            // 
            maskedTextBox16.Location = new Point(835, 101);
            maskedTextBox16.Name = "maskedTextBox16";
            maskedTextBox16.Size = new Size(125, 27);
            maskedTextBox16.TabIndex = 12;
            // 
            // maskedTextBox17
            // 
            maskedTextBox17.Location = new Point(835, 26);
            maskedTextBox17.Name = "maskedTextBox17";
            maskedTextBox17.Size = new Size(125, 27);
            maskedTextBox17.TabIndex = 13;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(771, 105);
            label22.Name = "label22";
            label22.Size = new Size(40, 20);
            label22.TabIndex = 13;
            label22.Text = "สาขา";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(502, 29);
            label11.Name = "label11";
            label11.Size = new Size(84, 20);
            label11.TabIndex = 9;
            label11.Text = "รหัสนักศึกษา";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(502, 108);
            label12.Name = "label12";
            label12.Size = new Size(84, 20);
            label12.TabIndex = 10;
            label12.Text = "รหัสนักศึกษา";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(259, 29);
            label9.Name = "label9";
            label9.Size = new Size(26, 20);
            label9.TabIndex = 9;
            label9.Text = "ชื่อ";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(259, 112);
            label10.Name = "label10";
            label10.Size = new Size(26, 20);
            label10.TabIndex = 10;
            label10.Text = "ชื่อ";
            // 
            // maskedTextBox10
            // 
            maskedTextBox10.Location = new Point(592, 105);
            maskedTextBox10.Name = "maskedTextBox10";
            maskedTextBox10.Size = new Size(125, 27);
            maskedTextBox10.TabIndex = 8;
            // 
            // maskedTextBox9
            // 
            maskedTextBox9.Location = new Point(592, 26);
            maskedTextBox9.Name = "maskedTextBox9";
            maskedTextBox9.Size = new Size(125, 27);
            maskedTextBox9.TabIndex = 7;
            // 
            // maskedTextBox5
            // 
            maskedTextBox5.Location = new Point(283, 22);
            maskedTextBox5.Name = "maskedTextBox5";
            maskedTextBox5.Size = new Size(125, 27);
            maskedTextBox5.TabIndex = 10;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(392, 425);
            label3.Name = "label3";
            label3.Size = new Size(147, 20);
            label3.TabIndex = 11;
            label3.Text = "นักศึกษาที่ได้เกรดสูงสุด:";
            // 
            // button3
            // 
            button3.Location = new Point(43, 374);
            button3.Name = "button3";
            button3.Size = new Size(174, 81);
            button3.TabIndex = 12;
            button3.Text = "รวม";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // maskedTextBox6
            // 
            maskedTextBox6.Location = new Point(283, 83);
            maskedTextBox6.Name = "maskedTextBox6";
            maskedTextBox6.Size = new Size(125, 27);
            maskedTextBox6.TabIndex = 13;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(240, 86);
            label4.Name = "label4";
            label4.Size = new Size(37, 20);
            label4.TabIndex = 14;
            label4.Text = "เกรด";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(label26);
            groupBox3.Controls.Add(label24);
            groupBox3.Controls.Add(maskedTextBox21);
            groupBox3.Controls.Add(label23);
            groupBox3.Controls.Add(label21);
            groupBox3.Controls.Add(maskedTextBox20);
            groupBox3.Controls.Add(maskedTextBox19);
            groupBox3.Controls.Add(label17);
            groupBox3.Controls.Add(label16);
            groupBox3.Controls.Add(label4);
            groupBox3.Controls.Add(label15);
            groupBox3.Controls.Add(maskedTextBox14);
            groupBox3.Controls.Add(maskedTextBox11);
            groupBox3.Controls.Add(label14);
            groupBox3.Controls.Add(label13);
            groupBox3.Controls.Add(maskedTextBox13);
            groupBox3.Controls.Add(maskedTextBox12);
            groupBox3.Controls.Add(maskedTextBox6);
            groupBox3.Controls.Add(maskedTextBox5);
            groupBox3.Location = new Point(310, 400);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(969, 125);
            groupBox3.TabIndex = 15;
            groupBox3.TabStop = false;
            groupBox3.Text = "ช่อง3";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(31, 82);
            label24.Name = "label24";
            label24.Size = new Size(0, 20);
            label24.TabIndex = 27;
            // 
            // maskedTextBox21
            // 
            maskedTextBox21.Location = new Point(82, 79);
            maskedTextBox21.Name = "maskedTextBox21";
            maskedTextBox21.Size = new Size(144, 27);
            maskedTextBox21.TabIndex = 26;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(792, 89);
            label23.Name = "label23";
            label23.Size = new Size(40, 20);
            label23.TabIndex = 25;
            label23.Text = "สาขา";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(425, 86);
            label21.Name = "label21";
            label21.Size = new Size(40, 20);
            label21.TabIndex = 24;
            label21.Text = "สาขา";
            // 
            // maskedTextBox20
            // 
            maskedTextBox20.Location = new Point(838, 83);
            maskedTextBox20.Name = "maskedTextBox20";
            maskedTextBox20.Size = new Size(125, 27);
            maskedTextBox20.TabIndex = 23;
            // 
            // maskedTextBox19
            // 
            maskedTextBox19.Location = new Point(471, 83);
            maskedTextBox19.Name = "maskedTextBox19";
            maskedTextBox19.Size = new Size(125, 27);
            maskedTextBox19.TabIndex = 22;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(607, 83);
            label17.Name = "label17";
            label17.Size = new Size(37, 20);
            label17.TabIndex = 21;
            label17.Text = "เกรด";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(800, 25);
            label16.Name = "label16";
            label16.Size = new Size(32, 20);
            label16.TabIndex = 20;
            label16.Text = "รหัส";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(433, 25);
            label15.Name = "label15";
            label15.Size = new Size(32, 20);
            label15.TabIndex = 19;
            label15.Text = "รหัส";
            // 
            // maskedTextBox14
            // 
            maskedTextBox14.Location = new Point(838, 22);
            maskedTextBox14.Name = "maskedTextBox14";
            maskedTextBox14.Size = new Size(125, 27);
            maskedTextBox14.TabIndex = 18;
            // 
            // maskedTextBox11
            // 
            maskedTextBox11.Location = new Point(471, 22);
            maskedTextBox11.Name = "maskedTextBox11";
            maskedTextBox11.Size = new Size(125, 27);
            maskedTextBox11.TabIndex = 17;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(618, 25);
            label14.Name = "label14";
            label14.Size = new Size(26, 20);
            label14.TabIndex = 16;
            label14.Text = "ชื่อ";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(251, 29);
            label13.Name = "label13";
            label13.Size = new Size(26, 20);
            label13.TabIndex = 15;
            label13.Text = "ชื่อ";
            // 
            // maskedTextBox13
            // 
            maskedTextBox13.Location = new Point(650, 22);
            maskedTextBox13.Name = "maskedTextBox13";
            maskedTextBox13.Size = new Size(125, 27);
            maskedTextBox13.TabIndex = 14;
            // 
            // maskedTextBox12
            // 
            maskedTextBox12.Location = new Point(650, 80);
            maskedTextBox12.Name = "maskedTextBox12";
            maskedTextBox12.Size = new Size(125, 27);
            maskedTextBox12.TabIndex = 1;
            // 
            // button4
            // 
            button4.Location = new Point(143, 496);
            button4.Name = "button4";
            button4.Size = new Size(94, 29);
            button4.TabIndex = 16;
            button4.Text = "ล้างข้อมูล";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // maskedTextBox22
            // 
            maskedTextBox22.Location = new Point(145, 110);
            maskedTextBox22.Name = "maskedTextBox22";
            maskedTextBox22.Size = new Size(125, 27);
            maskedTextBox22.TabIndex = 15;
            // 
            // maskedTextBox23
            // 
            maskedTextBox23.Location = new Point(128, 98);
            maskedTextBox23.Name = "maskedTextBox23";
            maskedTextBox23.Size = new Size(125, 27);
            maskedTextBox23.TabIndex = 16;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(66, 112);
            label25.Name = "label25";
            label25.Size = new Size(40, 20);
            label25.TabIndex = 16;
            label25.Text = "ห้อง1";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Location = new Point(56, 104);
            label27.Name = "label27";
            label27.Size = new Size(40, 20);
            label27.TabIndex = 17;
            label27.Text = "ห้อง2";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(25, 86);
            label26.Name = "label26";
            label26.Size = new Size(51, 20);
            label26.TabIndex = 18;
            label26.Text = "คำยินดี";
            // 
            // button5
            // 
            button5.Location = new Point(43, 496);
            button5.Name = "button5";
            button5.Size = new Size(94, 29);
            button5.TabIndex = 17;
            button5.Text = "เก็บข้อมูล";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1424, 577);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(label3);
            Controls.Add(button2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(groupBox1);
            Controls.Add(groupBox2);
            Controls.Add(groupBox3);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label1;
        private MaskedTextBox maskedTextBox1;
        private MaskedTextBox maskedTextBox2;
        private MaskedTextBox maskedTextBox3;
        private MaskedTextBox maskedTextBox4;
        private Label label2;
        private Button button2;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private MaskedTextBox maskedTextBox5;
        private Label label3;
        private Button button3;
        private MaskedTextBox maskedTextBox6;
        private Label label4;
        private MaskedTextBox maskedTextBox8;
        private MaskedTextBox maskedTextBox7;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private MaskedTextBox maskedTextBox10;
        private MaskedTextBox maskedTextBox9;
        private GroupBox groupBox3;
        private MaskedTextBox maskedTextBox12;
        private Label label11;
        private Label label12;
        private Label label9;
        private Label label10;
        private Button button4;
        private MaskedTextBox maskedTextBox13;
        private Label label17;
        private Label label16;
        private Label label15;
        private MaskedTextBox maskedTextBox14;
        private MaskedTextBox maskedTextBox11;
        private Label label14;
        private Label label13;
        private Label label20;
        private Label label19;
        private Label label18;
        private Label label22;
        private MaskedTextBox maskedTextBox18;
        private MaskedTextBox maskedTextBox16;
        private MaskedTextBox maskedTextBox15;
        private MaskedTextBox maskedTextBox17;
        private Label label23;
        private Label label21;
        private MaskedTextBox maskedTextBox20;
        private MaskedTextBox maskedTextBox19;
        private Label label24;
        private MaskedTextBox maskedTextBox21;
        private Label label25;
        private MaskedTextBox maskedTextBox22;
        private Label label27;
        private MaskedTextBox maskedTextBox23;
        private Label label26;
        private Button button5;
    }
}
