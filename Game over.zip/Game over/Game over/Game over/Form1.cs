using System;
using System.Windows.Forms;
using Game_over.Models;

namespace Game_over
{
    public partial class Form1 : Form
    {
        Advisor advisor1;
        Advisor advisor2;

        public Form1()
        {
            InitializeComponent();

            advisor1 = new Advisor { FirstName = "�.�����", LastName = "㨴�" };
            advisor1.Students.Add(new Student { FirstName = "��˭ԧ", LastName = "����", StudentID = "650011000-1", Major = "CS", Grade = 4.0 });
            advisor1.Students.Add(new Student { FirstName = "��ͧ", LastName = "�Ѳ����", StudentID = "650031101-2", Major = "IT", Grade = 3.5 });

            advisor2 = new Advisor { FirstName = "�.�����", LastName = "�ѡ���¹" };
            advisor2.Students.Add(new Student { FirstName = "�ҹ�", LastName = "�ء��", StudentID = "673450192-0", Major = "IT", Grade = 3.7 });
            advisor2.Students.Add(new Student { FirstName = "�����", LastName = "�����", StudentID = "673450193-8", Major = "IT", Grade = 2.8 });
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // �����ª��͹ѡ�֡�Ҩҡ�Ҩ�������ͧ
            var allStudents = advisor1.Students.Concat(advisor2.Students)
                                .OrderByDescending(s => s.Grade)
                                .ToList();

            var topStudent = allStudents[0]; // �ѡ�֡�ҷ�����ô�٧�ش
            var secondStudent = allStudents[1]; // �ѡ�֡�ҷ�����ô�ͧŧ��

            // �ʴ��Źѡ�֡���ô�٧�ش
            maskedTextBox5.Text = topStudent.FirstName + " " + topStudent.LastName;
            maskedTextBox11.Text = topStudent.StudentID;
            maskedTextBox6.Text = topStudent.Grade.ToString("F");
            maskedTextBox19.Text = topStudent.Major;
            maskedTextBox21.Text = "��㨴���";

            // �ʴ��Źѡ�֡�ҷ�����ô�ͧŧ��
            maskedTextBox13.Text = secondStudent.FirstName + " " + secondStudent.LastName;
            maskedTextBox14.Text = secondStudent.StudentID;
            maskedTextBox12.Text = secondStudent.Grade.ToString("F");
            maskedTextBox20.Text = secondStudent.Major;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            maskedTextBox4.Text = advisor1.Students[1].FirstName + " " + advisor1.Students[1].LastName;
            maskedTextBox1.Text = advisor1.Students[0].FirstName + " " + advisor1.Students[0].LastName;
            maskedTextBox8.Text = advisor1.Students[1].StudentID;
            maskedTextBox7.Text = advisor1.Students[0].StudentID;
            maskedTextBox15.Text = advisor1.Students[1].Major;
            maskedTextBox18.Text = advisor1.Students[0].Major;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            maskedTextBox2.Text = advisor2.Students[0].FirstName + " " + advisor2.Students[0].LastName;
            maskedTextBox9.Text = advisor2.Students[0].StudentID;
            maskedTextBox3.Text = advisor2.Students[1].FirstName + " " + advisor2.Students[1].LastName;
            maskedTextBox10.Text = advisor2.Students[1].StudentID;
            maskedTextBox17.Text = advisor2.Students[0].Major;
            maskedTextBox16.Text = advisor2.Students[1].Major;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            foreach (Control ctrl in Controls)
            {
                if (ctrl is MaskedTextBox)
                    ((MaskedTextBox)ctrl).Clear();

                if (ctrl is GroupBox)
                {
                    foreach (Control subCtrl in ctrl.Controls)
                    {
                        if (subCtrl is MaskedTextBox)
                            ((MaskedTextBox)subCtrl).Clear();
                    }
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            {
                // �����ª��͹ѡ�֡�ҷ������ҡ����֡�ҷ���ͧ
                var allStudents = advisor1.Students.Concat(advisor2.Students)
                                    .OrderByDescending(s => s.Grade)
                                    .ToList();

                // �ʴ������ź�˹�Ҩ�
                string message = "��ª��͹ѡ�֡�ҷ�����:\n";
                foreach (var student in allStudents)
                {
                    message += $"{student.FirstName} {student.LastName}, ����: {student.StudentID}, �Ң�: {student.Major}, �ô: {student.Grade:F2}\n";
                }

                // �ʴ�� MessageBox
                MessageBox.Show(message, "�����Źѡ�֡��", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}