﻿namespace Game_over.Models
{
    public class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string StudentID { get; set; }
        public string Major { get; set; }
        public double Grade { get; set; }
    }
}